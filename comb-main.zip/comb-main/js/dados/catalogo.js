/** Pacote JavaScript consolidado; as seções ORIGINAL preservam a origem do código.
 * Gerado a partir da versão-base auditada. Sem bibliotecas externas adicionais.
 */
const __modules = {
  "database.js": (__load, __exports) => {
    // ===== ORIGINAL: database.js =====

    /** Ponto de entrada do banco de gases (compatível com a API global original). */
    const { GASES_INORGANICOS: GASES_INORGANICOS } = __load("js/dados/01-inorganicos.js");
    const { GASES_LEVES: GASES_LEVES } = __load("js/dados/02-hidrocarbonetos-leves.js");
    const { GASES_ORGANICOS: GASES_ORGANICOS } = __load("js/dados/03-hidrocarbonetos-pesados.js");
    const { GASES_AUXILIARES: GASES_AUXILIARES } = __load("js/dados/04-produtos-auxiliares.js");
    const { GASES_ARGONIO: GASES_ARGONIO } = __load("js/dados/05-argonio.js");
    const { JMOL_SMILES_BY_ID: JMOL_SMILES_BY_ID } = __load("js/dados/smiles.js");
    // Ordem histórica preservada: não altera presets nem listas na interface.
    window.GAS_DATABASE = [
      ...GASES_INORGANICOS,
      ...GASES_LEVES,
      ...GASES_ORGANICOS,
      ...GASES_AUXILIARES,
      ...GASES_ARGONIO
    ];
    for (const gas of window.GAS_DATABASE) {
      if (!gas.smiles && JMOL_SMILES_BY_ID[gas.id]) {
        gas.smiles = JMOL_SMILES_BY_ID[gas.id];
      }
    }
  },
  "js/dados/01-inorganicos.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/01-inorganicos.js =====
    Object.defineProperty(__exports, "GASES_INORGANICOS", {
      enumerable: true,
      get: () => GASES_INORGANICOS
    });
    /**
     * Gases inorgânicos e permanentes
     * COMPONENTES: N2, NO, O2, NO2, H2, H2S, H2O, CO, CO2
     * PCS e PCI [MJ/kg], massa molar [kg/kmol], Cp° Shomate [J/(mol.K)].
     * Os valores e a ordem dos registros foram preservados.
     */
    const { G: G, N: N, J: J } = __load("js/dados/construtores.js");

    const GASES_INORGANICOS = [
      G(
        "N2",
        "Nitrogênio",
        "N₂",
        [0, 0, 2, 0, 0],
        28.014,
        0,
        0,
        "NIST / não combustível",

        N([
          [100, 500, 28.98641, 1.853978, -9.647459, 16.63537, 0.000117, -8.671914, 226.4168, 0],

          [500, 2000, 19.50583, 19.88705, -8.598535, 1.369784, 0.527601, -4.935202, 212.39, 0],

          [2000, 6000, 35.51872, 1.128728, -0.196103, 0.014662, -4.55376, -18.97091, 224.981, 0]
        ])
      ),

      G(
        "NO",
        "Óxido de Nitrogênio",
        "NO",
        [0, 0, 1, 1, 0],
        30.006,
        0,
        0,
        "NIST / não combustível",

        N([
          [
            298, 1200, 23.83491, 12.58878, -1.139011, -1.497459, 0.214194, 83.35783, 237.1219,
            90.29114
          ],

          [
            1200, 6000, 35.99169, 0.95717, -0.148032, 0.009974, -3.004088, 73.10787, 246.1619,
            90.29114
          ]
        ])
      ),

      G(
        "O2",
        "Oxigênio",
        "O₂",
        [0, 0, 0, 2, 0],
        31.998,
        0,
        0,
        "NIST / não combustível",

        N([
          [100, 700, 31.32234, -20.23531, 57.86644, -36.50624, -0.007374, -8.903471, 246.7945, 0],

          [700, 2000, 30.03235, 8.772972, -3.988133, 0.788313, -0.741599, -11.32468, 236.1663, 0],

          [2000, 6000, 20.91111, 10.72071, -2.020498, 0.146449, 9.245722, 5.337651, 237.6185, 0]
        ])
      ),

      G(
        "NO2",
        "Dióxido de Nitrogênio",
        "NO₂",
        [0, 0, 1, 2, 0],
        46.005,
        0,
        0,
        "NIST / não combustível",

        N([
          [
            298, 1200, 16.10857, 75.89525, -54.3874, 14.30777, 0.239423, 26.17464, 240.5386,
            33.09502
          ],

          [
            1200, 6000, 56.82541, 0.738053, -0.144721, 0.009777, -5.459911, 2.846456, 290.5056,
            33.09502
          ]
        ])
      ),

      G(
        "H2",
        "Hidrogênio",
        "H₂",
        [0, 2, 0, 0, 0],
        2.016,
        141.9296,
        119.9008,
        "ISO 6976 / NIST",

        N([
          [
            298, 1000, 33.066178, -11.363417, 11.432816, -2.772874, -0.158558, -9.980797,
            172.707974, 0
          ],

          [
            1000, 2500, 18.563083, 12.257357, -2.859786, 0.268238, 1.97799, -1.147438, 156.288133, 0
          ],

          [
            2500, 6000, 43.41356, -4.293079, 1.272428, -0.096876, -20.533862, -38.515158,
            162.081354, 0
          ]
        ])
      ),

      G(
        "H2S",
        "Hydrogen sulfide",
        "H₂S",
        [0, 2, 0, 0, 1],
        34.076,
        16.5031,
        15.1998,
        "ISO 6976 / NIST",

        N([
          [
            298, 1400, 26.88412, 18.67809, 3.434203, -3.378702, 0.135882, -28.91211, 233.3747,
            -20.50202
          ],

          [
            1400, 6000, 51.22136, 4.147486, -0.643566, 0.041621, -10.46385, -55.87606, 243.69,
            -20.50202
          ]
        ])
      ),

      G(
        "H2O",
        "Água",
        "H₂O",
        [0, 2, 0, 1, 0],
        18.015,
        0,
        0,
        "NIST / não combustível",

        N([
          [
            500, 1700, 30.092, 6.832514, 6.793435, -2.53448, 0.082139, -250.881, 223.3967, -241.8264
          ],

          [
            1700, 6000, 41.96426, 8.622053, -1.49978, 0.098119, -11.15764, -272.1797, 219.7809,
            -241.8264
          ]
        ])
      ),

      G(
        "CO",
        "Monóxido de Carbono",
        "CO",
        [1, 0, 0, 1, 0],
        28.01,
        10.1003,
        10.1003,
        "ISO 6976 / NIST",

        N([
          [
            298, 1300, 25.56759, 6.09613, 4.054656, -2.671301, 0.131021, -118.0089, 227.3665,
            -110.5271
          ],

          [
            1300, 6000, 35.1507, 1.300095, -0.205921, 0.01355, -3.28278, -127.8375, 231.712,
            -110.5271
          ]
        ])
      ),

      G(
        "CO2",
        "Gás Carbônico",
        "CO₂",
        [1, 0, 0, 2, 0],
        44.009,
        0,
        0,
        "NIST / não combustível",

        N([
          [
            298, 1200, 24.99735, 55.18696, -33.69137, 7.948387, -0.136638, -403.6075, 228.2431,
            -393.5224
          ],

          [
            1200, 6000, 58.16639, 2.720074, -0.492289, 0.038844, -6.447293, -425.9186, 263.6125,
            -393.5224
          ]
        ])
      )
    ];
  },
  "js/dados/construtores.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/construtores.js =====
    Object.defineProperty(__exports, "N", { enumerable: true, get: () => N });
    Object.defineProperty(__exports, "J", { enumerable: true, get: () => J });
    Object.defineProperty(__exports, "G", { enumerable: true, get: () => G });
    /**
     * Construtores de propriedades termodinâmicas
     * N: Shomate NIST; J: Joback em base Shomate; G: registro de gás.
     * Extraído da implementação validada, sem modificar fórmulas ou fatores.
     */
    const N = (faixas) => ({
      metodo: "NIST_SHOMATE",
      estimado: false,
      fonte: "NIST Chemistry WebBook, SRD 69",
      faixas: faixas.map((f) => ({
        Tmin: f[0],
        Tmax: f[1],
        A: f[2],
        B: f[3],
        C: f[4],
        D: f[5],
        E: f[6],
        F: f[7],
        G: f[8],
        H: f[9]
      }))
    });
    const J = (smiles, grupos, A, B, C, D) => ({
      metodo: "JOBACK_SHOMATE",
      estimado: true,
      fonte: "Joback-Reid; convertido para forma Shomate",
      gruposJoback: grupos,
      faixas: [
        {
          Tmin: 298.15,
          Tmax: 1000,
          A,
          B,
          C,
          D,
          E: 0,
          F: null,
          G: null,
          H: null
        }
      ],
      smiles
    });
    const G = (id, nome, formula, a, M, pcs, pci, fonte, cp) => ({
      id,
      nome,
      formula,
      atomos: {
        C: a[0],
        H: a[1],
        N: a[2],
        O: a[3],
        S: a[4],
        Ar: id === "AR" ? 1 : 0
      },
      massaMolar: M,
      pcs,
      pci,
      fontePcsPci: fonte,
      ...(cp.smiles ? { smiles: cp.smiles } : {}),
      cpShomate: {
        metodo: cp.metodo,
        estimado: cp.estimado,
        fonte: cp.fonte,
        ...(cp.gruposJoback
          ? {
              gruposJoback: cp.gruposJoback
            }
          : {}),
        faixas: cp.faixas
      }
    });
  },
  "js/dados/02-hidrocarbonetos-leves.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/02-hidrocarbonetos-leves.js =====
    Object.defineProperty(__exports, "GASES_LEVES", { enumerable: true, get: () => GASES_LEVES });
    /**
     * Metano e hidrocarbonetos leves C1–C4
     * COMPONENTES: CH4, C2H2, C2H4, C2H6, C3H4_PROPADIENO, C3H4_PROPINO, C3H6, C3H8, C4H6_12BUTADIENO, C4H6_1BUTINO, C4H6_2BUTINO, C4H8_ISOBUTENO, C4H8_1BUTENO, C4H8_CIS2BUTENO, C4H8_TRANS2BUTENO, C4H10_NBUTANO, C4H10_ISOBUTANO
     * PCS e PCI [MJ/kg], massa molar [kg/kmol], Cp° Shomate [J/(mol.K)].
     * Os valores e a ordem dos registros foram preservados.
     */
    const { G: G, N: N, J: J } = __load("js/dados/construtores.js");

    const GASES_LEVES = [
      G(
        "CH4",
        "Metano",
        "CH₄",
        [1, 4, 0, 0, 0],
        16.043,
        55.57,
        50.0337,
        "ISO 6976 / NIST",

        N([
          [
            298, 1300, -0.703029, 108.4773, -42.52157, 5.862788, 0.678565, -76.84376, 158.7163,
            -74.8731
          ],

          [
            1300, 6000, 85.81217, 11.26467, -2.114146, 0.13819, -26.42221, -153.5327, 224.4143,
            -74.8731
          ]
        ])
      ),

      G(
        "C2H2",
        "Etino (Acetileno)",
        "C₂H₂",
        [2, 2, 0, 0, 0],
        26.038,
        49.9789,
        48.2733,
        "ISO 6976",

        N([
          [
            298, 1100, 40.68697, 40.73279, -16.1784, 3.669741, -0.658411, 210.7067, 235.0052,
            226.7314
          ],

          [
            1100, 6000, 67.47244, 11.7511, -2.02147, 0.136195, -9.806418, 185.455, 253.5337,
            226.7314
          ]
        ])
      ),

      G(
        "C2H4",
        "Eteno (Etileno)",
        "C₂H₄",
        [2, 4, 0, 0, 0],
        28.054,
        50.3336,
        47.1676,
        "ISO 6976",

        N([
          [
            298, 1200, -6.38788, 184.4019, -112.9718, 28.49593, 0.31554, 48.17332, 163.1568,
            52.46694
          ],

          [
            1200, 6000, 106.5104, 13.7326, -2.628481, 0.174595, -26.14469, -35.36237, 275.0424,
            52.46694
          ]
        ])
      ),

      G(
        "C2H6",
        "Etano",
        "C₂H₆",
        [2, 6, 0, 0, 0],
        30.07,
        51.9475,
        47.5168,
        "ISO 6976",
        J("CC", { "1": 2 }, 1.07, 193.84, -85, 12.6)
      ),

      G(
        "C3H4_PROPADIENO",
        "Propadieno",
        "C₃H₄",
        [3, 4, 0, 0, 0],
        40.065,
        48.5189,
        46.302,
        "ISO 6976",
        J("C=C=C", { "5": 2, "8": 1 }, 36.67, 78.1, 54, -50.2)
      ),

      G(
        "C3H4_PROPINO",
        "Propino (Metilacetileno)",
        "C₃H₄",
        [3, 4, 0, 0, 0],
        40.065,
        48.2,
        46,
        "Estimativa por analogia de isômero/homólogo",
        J("CC#C", { "1": 1, "9": 1, "10": 1 }, 13.94, 194.92, -135.33, 42.89)
      ),

      G(
        "C3H6",
        "Propeno (Propileno)",
        "C₃H₆",
        [3, 6, 0, 0, 0],
        42.081,
        48.9378,
        45.7717,
        "ISO 6976",
        J("CC=C", { "1": 1, "5": 1, "6": 1 }, -2.83, 268.82, -162.3, 41.9)
      ),

      G(
        "C3H8",
        "Propano",
        "C₃H₈",
        [3, 8, 0, 0, 0],
        44.097,
        50.366,
        46.3376,
        "ISO 6976",
        J("CCC", { "1": 2, "2": 1 }, 0.161, 288.84, -139.4, 24.5)
      ),

      G(
        "C4H6_12BUTADIENO",
        "1,2-Butadieno",
        "C₄H₆",
        [4, 6, 0, 0, 0],
        54.092,
        47.9747,
        45.5117,
        "ISO 6976",
        J("C=C=CC", { "1": 1, "5": 1, "6": 1, "8": 1 }, 24.57, 213.12, -61.3, -8.3)
      ),

      G(
        "C4H6_1BUTINO",
        "1-Butino (Etilacetileno)",
        "C₄H₆",
        [4, 6, 0, 0, 0],
        54.092,
        47.5,
        45,
        "Estimativa por analogia de isômero/homólogo",
        J("C#CCC", { "1": 1, "2": 1, "9": 1, "10": 1 }, 13.031, 289.92, -189.73, 54.79)
      ),

      G(
        "C4H6_2BUTINO",
        "2-Butino (Dimetilacetileno)",
        "C₄H₆",
        [4, 6, 0, 0, 0],
        54.092,
        47.2,
        44.7,
        "Estimativa por analogia de isômero/homólogo",
        J("CC#CC", { "1": 2, "10": 2 }, 16.81, 234.04, -101.66, 15.38)
      ),

      G(
        "C4H8_ISOBUTENO",
        "2-Metilpropeno",
        "C₄H₈",
        [4, 8, 0, 0, 0],
        56.108,
        48.1553,
        44.99,
        "ISO 6976",
        J("C=C(C)C", { "1": 2, "5": 1, "7": 1 }, -3.43, 363.74, -219, 55.6)
      ),

      G(
        "C4H8_1BUTENO",
        "Buteno",
        "C₄H₈",
        [4, 8, 0, 0, 0],
        56.108,
        48.4528,
        45.2869,
        "ISO 6976",
        J("C=CCC", { "1": 1, "2": 1, "5": 1, "6": 1 }, -3.739, 363.82, -216.7, 53.8)
      ),

      G(
        "C4H8_CIS2BUTENO",
        "cis-2-Buteno",
        "C₄H₈",
        [4, 8, 0, 0, 0],
        56.108,
        48.3318,
        45.1665,
        "ISO 6976",
        J("C/C=C\\C", { "1": 2, "6": 2 }, -14.93, 403.84, -277.6, 83.8)
      ),

      G(
        "C4H8_TRANS2BUTENO",
        "trans-2-Buteno",
        "C₄H₈",
        [4, 8, 0, 0, 0],
        56.108,
        48.2676,
        45.1005,
        "ISO 6976",
        J("C/C=C/C", { "1": 2, "6": 2 }, -14.93, 403.84, -277.6, 83.8)
      ),

      G(
        "C4H10_NBUTANO",
        "n-Butano",
        "C₄H₁₀",
        [4, 10, 0, 0, 0],
        58.124,
        49.5429,
        45.7226,
        "ISO 6976",
        J("CCCC", { "1": 2, "2": 2 }, -0.748, 383.84, -193.8, 36.4)
      ),

      G(
        "C4H10_ISOBUTANO",
        "2-Metilpropano (Isobutano)",
        "C₄H₁₀",
        [4, 10, 0, 0, 0],
        58.124,
        49.3849,
        45.5647,
        "ISO 6976",
        J("CC(C)C", { "1": 3, "3": 1 }, -2.43, 389.76, -197, 35.9)
      )
    ];
  },
  "js/dados/03-hidrocarbonetos-pesados.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/03-hidrocarbonetos-pesados.js =====
    Object.defineProperty(__exports, "GASES_ORGANICOS", {
      enumerable: true,
      get: () => GASES_ORGANICOS
    });
    /**
     * Hidrocarbonetos C5–C10
     * COMPONENTES: C5H8_1PENTINO, C5H10_CICLOPENTANO, C5H10_CIS2PENTENO, C5H10_TRANS2PENTENO, C5H10_1PENTENO, C5H12_ISOPENTANO, C5H12_NPENTANO, C5H12_NEOPENTANO, C6H6_BENZENO, C6H12_METILCICLOPENTANO, C6H12_CICLOHEXANO, C6H14_22DMB, C6H14_23DMB, C6H14_2MP, C6H14_3MP, C6H14_NHEXANO, C7H8_TOLUENO, C7H14_METILCICLOHEXANO, C7H14_ETILCICLOPENTANO, C7H16_3EP, C7H16_223TMB, C7H16_NHEPTANO, C7H16_3MH, C8H18_4MH, C8H18_NOCTANO, C8H18_2M3EP, C8H18_22DMH, C8H18_25DMH, C8H18_223TMP, C8H18_224TMP, C8H18_2233TMB, C8H18_233TMP, C8H18_234TMP, C8H18_24DMH, C9H12_M_ETILBENZENO, C9H12_NPROPILBENZENO, C9H12_CUMENO, C9H12_P_ETILBENZENO, C9H12_O_ETILBENZENO, C9H18_NBUTILCICLOPENTANO, C9H18_NPROPILCICLOHEXANO, C10H14_NBUTILBENZENO, C10H20_NBUTILCICLOHEXANO
     * PCS e PCI [MJ/kg], massa molar [kg/kmol], Cp° Shomate [J/(mol.K)].
     * Os valores e a ordem dos registros foram preservados.
     */
    const { G: G, N: N, J: J } = __load("js/dados/construtores.js");

    const GASES_ORGANICOS = [
      G(
        "C5H8_1PENTINO",
        "1-Pentino",
        "C₅H₈",
        [5, 8, 0, 0, 0],
        68.119,
        47.1,
        44.5,
        "Estimativa por analogia de isômero/homólogo",
        J("C#CCCC", { "1": 1, "2": 2, "9": 1, "10": 1 }, 12.122, 384.92, -244.13, 66.69)
      ),

      G(
        "C5H10_CICLOPENTANO",
        "Ciclopentano",
        "C₅H₁₀",
        [5, 10, 0, 0, 0],
        70.135,
        47.3664,
        44.2005,
        "ISO 6976",
        J("C1CCCC1", { "11": 5 }, -68.08, 637, -431, 116)
      ),

      G(
        "C5H10_CIS2PENTENO",
        "cis-2-Penteno",
        "C₅H₁₀",
        [5, 10, 0, 0, 0],
        70.135,
        48.1588,
        44.9928,
        "Estimativa por analogia de isômero/homólogo",
        J("C/C=C\\CC", { "1": 2, "2": 1, "6": 2 }, -15.839, 498.84, -332, 95.7)
      ),

      G(
        "C5H10_TRANS2PENTENO",
        "trans-2-Penteno",
        "C₅H₁₀",
        [5, 10, 0, 0, 0],
        70.135,
        48.1588,
        44.9928,
        "Estimativa por analogia de isômero/homólogo",
        J("C/C=C/CC", { "1": 2, "2": 1, "6": 2 }, -15.839, 498.84, -332, 95.7)
      ),

      G(
        "C5H10_1PENTENO",
        "1-Penteno",
        "C₅H₁₀",
        [5, 10, 0, 0, 0],
        70.135,
        48.1588,
        44.9928,
        "ISO 6976",
        J("C=CCCC", { "1": 1, "2": 2, "5": 1, "6": 1 }, -4.648, 458.82, -271.1, 65.7)
      ),

      G(
        "C5H12_ISOPENTANO",
        "2-Metilbutano (Isopentano)",
        "C₅H₁₂",
        [5, 12, 0, 0, 0],
        72.151,
        48.9462,
        45.2531,
        "ISO 6976",
        J("CC(C)CC", { "1": 3, "2": 1, "3": 1 }, -3.339, 484.76, -251.4, 47.8)
      ),

      G(
        "C5H12_NPENTANO",
        "n-Pentano",
        "C₅H₁₂",
        [5, 12, 0, 0, 0],
        72.151,
        49.0421,
        45.3491,
        "ISO 6976",
        J("CCCCC", { "1": 2, "2": 3 }, -1.657, 478.84, -248.2, 48.3)
      ),

      G(
        "C5H12_NEOPENTANO",
        "Neopentano (2,2-Dimetilpropano)",
        "C₅H₁₂",
        [5, 12, 0, 0, 0],
        72.151,
        48.7487,
        45.0556,
        "ISO 6976",
        J("CC(C)(C)C", { "1": 4, "4": 1 }, -26.13, 604.68, -420, 120.2)
      ),

      G(
        "C6H6_BENZENO",
        "Benzeno",
        "C₆H₆",
        [6, 6, 0, 0, 0],
        78.114,
        42.2815,
        40.576,
        "ISO 6976",
        J("c1ccccc1", { "14": 6 }, -50.77, 554.4, -400.84, 110.6)
      ),

      G(
        "C6H12_METILCICLOPENTANO",
        "Metilciclopentano",
        "C₆H₁₂",
        [6, 12, 0, 0, 0],
        84.162,
        47.1981,
        44.0321,
        "ISO 6976",
        J("CC1CCCC1", { "1": 1, "11": 4, "12": 1 }, -63.05, 705.52, -430, 99.7)
      ),

      G(
        "C6H12_CICLOHEXANO",
        "Ciclohexano",
        "C₆H₁₂",
        [6, 12, 0, 0, 0],
        84.162,
        47.0028,
        43.8368,
        "ISO 6976",
        J("C1CCCCC1", { "11": 6 }, -74.11, 722.4, -439, 98)
      ),

      G(
        "C6H14_22DMB",
        "2,2-Dimetilbutano",
        "C₆H₁₄",
        [6, 14, 0, 0, 0],
        86.178,
        48.5117,
        44.9045,
        "ISO 6976",
        J("CC(C)(C)CC", { "1": 4, "2": 1, "4": 1 }, -27.039, 699.68, -474.4, 132.1)
      ),

      G(
        "C6H14_23DMB",
        "2,3-Dimetilbutano",
        "C₆H₁₄",
        [6, 14, 0, 0, 0],
        86.178,
        48.6018,
        44.9947,
        "ISO 6976",
        J("CC(C)C(C)C", { "1": 4, "3": 2 }, -5.93, 585.68, -309, 59.2)
      ),

      G(
        "C6H14_2MP",
        "2-Metilpentano",
        "C₆H₁₄",
        [6, 14, 0, 0, 0],
        86.178,
        48.6253,
        45.0181,
        "ISO 6976",
        J("CC(C)CCC", { "1": 3, "2": 2, "3": 1 }, -4.248, 579.76, -305.8, 59.7)
      ),

      G(
        "C6H14_3MP",
        "3-Metilpentano",
        "C₆H₁₄",
        [6, 14, 0, 0, 0],
        86.178,
        48.6555,
        45.0483,
        "ISO 6976",
        J("CCC(C)CC", { "1": 3, "2": 2, "3": 1 }, -4.248, 579.76, -305.8, 59.7)
      ),

      G(
        "C6H14_NHEXANO",
        "Hexano (n-Hexano)",
        "C₆H₁₄",
        [6, 14, 0, 0, 0],
        86.178,
        48.7138,
        45.1065,
        "ISO 6976",
        J("CCCCCC", { "1": 2, "2": 4 }, -2.566, 573.84, -302.6, 60.2)
      ),

      G(
        "C7H8_TOLUENO",
        "Metilbenzeno (Tolueno)",
        "C₇H₈",
        [7, 8, 0, 0, 0],
        92.141,
        42.8658,
        40.938,
        "ISO 6976",
        J("Cc1ccccc1", { "1": 1, "14": 5, "15": 1 }, -37.38, 589.92, -388.2, 97.6)
      ),

      G(
        "C7H14_METILCICLOHEXANO",
        "Metilciclohexano",
        "C₇H₁₄",
        [7, 14, 0, 0, 0],
        98.189,
        46.8881,
        43.7221,
        "ISO 6976",
        J("CC1CCCCC1", { "1": 1, "11": 5, "12": 1 }, -69.08, 790.92, -438, 81.7)
      ),

      G(
        "C7H14_ETILCICLOPENTANO",
        "Etilciclopentano",
        "C₇H₁₄",
        [7, 14, 0, 0, 0],
        98.189,
        47.1718,
        44.0058,
        "ISO 6976",
        J("CCC1CCCC1", { "1": 1, "2": 1, "11": 4, "12": 1 }, -63.959, 800.52, -484.4, 111.6)
      ),

      G(
        "C7H16_3EP",
        "3-Etilpentano",
        "C₇H₁₆",
        [7, 16, 0, 0, 0],
        100.205,
        48.4703,
        44.9248,
        "Estimativa por analogia de isômero/homólogo",
        J("CCC(CC)CC", { "1": 3, "2": 3, "3": 1 }, -5.157, 674.76, -360.2, 71.6)
      ),

      G(
        "C7H16_223TMB",
        "2,2,3-Trimetilbutano",
        "C₇H₁₆",
        [7, 16, 0, 0, 0],
        100.205,
        48.4703,
        44.9248,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)(C)C(C)C", { "1": 5, "3": 1, "4": 1 }, -29.63, 800.6, -532, 143.5)
      ),

      G(
        "C7H16_NHEPTANO",
        "n-Heptano",
        "C₇H₁₆",
        [7, 16, 0, 0, 0],
        100.205,
        48.4703,
        44.9248,
        "ISO 6976",
        J("CCCCCCC", { "1": 2, "2": 5 }, -3.475, 668.84, -357, 72.1)
      ),

      G(
        "C7H16_3MH",
        "3-Metilhexano",
        "C₇H₁₆",
        [7, 16, 0, 0, 0],
        100.205,
        48.4703,
        44.9248,
        "Estimativa por analogia de isômero/homólogo",
        J("CCC(C)CCC", { "1": 3, "2": 3, "3": 1 }, -5.157, 674.76, -360.2, 71.6)
      ),

      G(
        "C8H18_4MH",
        "4-Metilheptano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CCCC(C)CCC", { "1": 3, "2": 4, "3": 1 }, -6.066, 769.76, -414.6, 83.5)
      ),

      G(
        "C8H18_NOCTANO",
        "n-Octano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "ISO 6976",
        J("CCCCCCCC", { "1": 2, "2": 6 }, -4.384, 763.84, -411.4, 84)
      ),

      G(
        "C8H18_2M3EP",
        "2-Metil-3-etilpentano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)C(CC)CC", { "1": 4, "2": 2, "3": 2 }, -7.748, 775.68, -417.8, 83)
      ),

      G(
        "C8H18_22DMH",
        "2,2-Dimetilhexano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)(C)CCCC", { "1": 4, "2": 3, "4": 1 }, -28.857, 889.68, -583.2, 155.9)
      ),

      G(
        "C8H18_25DMH",
        "2,5-Dimetilhexano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)CCC(C)C", { "1": 4, "2": 2, "3": 2 }, -7.748, 775.68, -417.8, 83)
      ),

      G(
        "C8H18_223TMP",
        "2,2,3-Trimetilpentano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)(C)C(C)CC", { "1": 5, "2": 1, "3": 1, "4": 1 }, -30.539, 895.6, -586.4, 155.4)
      ),

      G(
        "C8H18_224TMP",
        "2,2,4-Trimetilpentano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)CC(C)(C)C", { "1": 5, "2": 1, "3": 1, "4": 1 }, -30.539, 895.6, -586.4, 155.4)
      ),

      G(
        "C8H18_2233TMB",
        "2,2,3,3-Tetrametilbutano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)(C)C(C)(C)C", { "1": 6, "4": 2 }, -53.33, 1015.52, -755, 227.8)
      ),

      G(
        "C8H18_233TMP",
        "2,3,3-Trimetilpentano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)C(C)(C)CC", { "1": 5, "2": 1, "3": 1, "4": 1 }, -30.539, 895.6, -586.4, 155.4)
      ),

      G(
        "C8H18_234TMP",
        "2,3,4-Trimetilpentano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)C(C)C(C)C", { "1": 5, "3": 3 }, -9.43, 781.6, -421, 82.5)
      ),

      G(
        "C8H18_24DMH",
        "2,4-Dimetilhexano",
        "C₈H₁₈",
        [8, 18, 0, 0, 0],
        114.232,
        48.2857,
        44.7867,
        "Estimativa por analogia de isômero/homólogo",
        J("CC(C)CC(C)CC", { "1": 4, "2": 2, "3": 2 }, -7.748, 775.68, -417.8, 83)
      ),

      G(
        "C9H12_M_ETILBENZENO",
        "1-Metil-3-etilbenzeno",
        "C₉H₁₂",
        [9, 12, 0, 0, 0],
        120.195,
        43.2548,
        41.043,
        "Channiwala–Parikh + correção PCI",
        J("Cc1cc(CC)ccc1", { "1": 2, "2": 1, "14": 4, "15": 2 }, -24.899, 720.44, -429.96, 96.5)
      ),

      G(
        "C9H12_NPROPILBENZENO",
        "n-Propilbenzeno",
        "C₉H₁₂",
        [9, 12, 0, 0, 0],
        120.195,
        43.2548,
        41.043,
        "Channiwala–Parikh + correção PCI",
        J("CCCc1ccccc1", { "1": 1, "2": 2, "14": 5, "15": 1 }, -39.198, 779.92, -497, 121.4)
      ),

      G(
        "C9H12_CUMENO",
        "Isopropilbenzeno (cumeno)",
        "C₉H₁₂",
        [9, 12, 0, 0, 0],
        120.195,
        43.2548,
        41.043,
        "Channiwala–Parikh + correção PCI",
        J("CC(C)c1ccccc1", { "1": 2, "3": 1, "14": 5, "15": 1 }, -40.88, 785.84, -500.2, 120.9)
      ),

      G(
        "C9H12_P_ETILBENZENO",
        "1-Metil-4-etilbenzeno",
        "C₉H₁₂",
        [9, 12, 0, 0, 0],
        120.195,
        43.2548,
        41.043,
        "Channiwala–Parikh + correção PCI",
        J("Cc1ccc(CC)cc1", { "1": 2, "2": 1, "14": 4, "15": 2 }, -24.899, 720.44, -429.96, 96.5)
      ),

      G(
        "C9H12_O_ETILBENZENO",
        "1-Metil-2-etilbenzeno",
        "C₉H₁₂",
        [9, 12, 0, 0, 0],
        120.195,
        43.2548,
        41.043,
        "Channiwala–Parikh + correção PCI",
        J("Cc1ccccc1CC", { "1": 2, "2": 1, "14": 4, "15": 2 }, -24.899, 720.44, -429.96, 96.5)
      ),

      G(
        "C9H18_NBUTILCICLOPENTANO",
        "n-Butilciclopentano",
        "C₉H₁₈",
        [9, 18, 0, 0, 0],
        126.243,
        46.8275,
        43.6688,
        "Channiwala–Parikh + correção PCI",
        J("CCCCC1CCCC1", { "1": 1, "2": 3, "11": 4, "12": 1 }, -65.777, 990.52, -593.2, 135.4)
      ),

      G(
        "C9H18_NPROPILCICLOHEXANO",
        "n-Propilciclohexano",
        "C₉H₁₈",
        [9, 18, 0, 0, 0],
        126.243,
        46.8275,
        43.6688,
        "Channiwala–Parikh + correção PCI",
        J("CCCC1CCCCC1", { "1": 1, "2": 2, "11": 5, "12": 1 }, -70.898, 980.92, -546.8, 105.5)
      ),

      G(
        "C10H14_NBUTILBENZENO",
        "n-Butilbenzeno",
        "C₁₀H₁₄",
        [10, 14, 0, 0, 0],
        134.222,
        43.6281,
        41.3174,
        "Channiwala–Parikh + correção PCI",
        J("CCCCc1ccccc1", { "1": 1, "2": 3, "14": 5, "15": 1 }, -40.107, 874.92, -551.4, 133.3)
      ),

      G(
        "C10H20_NBUTILCICLOHEXANO",
        "n-Butilciclohexano",
        "C₁₀H₂₀",
        [10, 20, 0, 0, 0],
        140.27,
        46.8275,
        43.6688,
        "Channiwala–Parikh + correção PCI",
        J("CCCCC1CCCCC1", { "1": 1, "2": 3, "11": 5, "12": 1 }, -71.807, 1075.92, -601.2, 117.4)
      )
    ];
  },
  "js/dados/04-produtos-auxiliares.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/04-produtos-auxiliares.js =====
    Object.defineProperty(__exports, "GASES_AUXILIARES", {
      enumerable: true,
      get: () => GASES_AUXILIARES
    });
    /**
     * SO₂, componente auxiliar de produtos
     * COMPONENTES: SO2
     * PCS e PCI [MJ/kg], massa molar [kg/kmol], Cp° Shomate [J/(mol.K)].
     * Os valores e a ordem dos registros foram preservados.
     */
    const { G: G, N: N, J: J } = __load("js/dados/construtores.js");

    const GASES_AUXILIARES = [
      G(
        "SO2",
        "Dióxido de Enxofre",
        "SO₂",
        [0, 0, 0, 2, 1],
        64.058,
        0,
        0,
        "Não combustível; produto de combustão",

        N([
          [
            298, 1200, 21.43049, 74.35094, -57.75217, 16.35534, 0.086731, -305.7688, 254.8872,
            -296.8422
          ],

          [
            1200, 6000, 57.48188, 1.009328, -0.07629, 0.005174, -4.045401, -324.414, 302.7798,
            -296.8422
          ]
        ])
      )
    ];
  },
  "js/dados/05-argonio.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/05-argonio.js =====
    Object.defineProperty(__exports, "GASES_ARGONIO", {
      enumerable: true,
      get: () => GASES_ARGONIO
    });
    /**
     * Argônio, gás monoatômico inerte presente no ar seco.
     * Fonte de Cp: NIST Chemistry WebBook (Chase, 1998), Shomate 298–6000 K.
     * https://webbook.nist.gov/cgi/cbook.cgi?ID=C7440371&Mask=5
     * Apenas a modelagem do gás Ar na entrada combustível; o comburente
     * continua usando o modelo simplificado O2/N2/H2O original.
     */
    const { G: G, N: N } = __load("js/dados/construtores.js");

    const GASES_ARGONIO = [
      G(
        "AR",
        "Argônio",
        "Ar",
        [0, 0, 0, 0, 0],
        39.948,
        0,
        0,
        "NIST Chemistry WebBook / gás não combustível",
        N([
          [
            298, 6000, 20.786, 2.825911e-7, -1.464191e-7, 1.092131e-8, -3.661371e-8, -6.19735,
            179.999, 0
          ]
        ])
      )
    ];
  },
  "js/dados/smiles.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/smiles.js =====
    Object.defineProperty(__exports, "JMOL_SMILES_BY_ID", {
      enumerable: true,
      get: () => JMOL_SMILES_BY_ID
    });
    /**
     * SMILES de espécies com Cp de referência
     * Apenas visualização 3D; não entra no cálculo.
     * Extraído da implementação validada, sem modificar fórmulas ou fatores.
     */
    const JMOL_SMILES_BY_ID = Object.freeze({
      // Gás nobre monoatômico: representa um átomo isolado, sem ligações.
      AR: "[Ar]",
      N2: "N#N",
      NO: "[N]=O",
      O2: "O=O",
      NO2: "[N+](=O)[O-]",
      H2: "[H][H]",
      H2S: "S",
      H2O: "O",
      CO: "[C-]#[O+]",
      CO2: "O=C=O",
      CH4: "C",
      C2H2: "C#C",
      C2H4: "C=C",
      SO2: "O=S=O"
    });
  },
  "presets.js": (__load, __exports) => {
    // ===== ORIGINAL: presets.js =====

    /** Exposição de presets para a interface legada. */
    const { COMBUSTION_PRESETS: COMBUSTION_PRESETS } = __load("js/dados/presets-gases.js");
    window.COMBUSTION_PRESETS = COMBUSTION_PRESETS;
  },
  "js/dados/presets-gases.js": (__load, __exports) => {
    // ===== ORIGINAL: js/dados/presets-gases.js =====
    Object.defineProperty(__exports, "COMBUSTION_PRESETS", {
      enumerable: true,
      get: () => COMBUSTION_PRESETS
    });
    /**
     * Composições de referência (presets)
     * Frações molares em %. Valores históricos mantidos.
     * Extraído da implementação validada, sem modificar fórmulas ou fatores.
     */
    const COMBUSTION_PRESETS = {
      cog: {
        nome: "Gás de coqueria",
        observacao: "Composição representativa em base molar; ajuste pela análise real.",
        componentes: [
          {
            id: "H2",
            percentual: 57.0
          },
          {
            id: "CH4",
            percentual: 27.0
          },
          {
            id: "CO",
            percentual: 7.0
          },
          {
            id: "CO2",
            percentual: 2.0
          },
          {
            id: "N2",
            percentual: 5.0
          },
          {
            id: "C2H4",
            percentual: 2.0
          }
        ]
      },
      bfg: {
        nome: "Gás de alto-forno",
        observacao: "Composição representativa em base molar; ajuste pela análise real.",
        componentes: [
          {
            id: "CO",
            percentual: 22.0
          },
          {
            id: "CO2",
            percentual: 19.0
          },
          {
            id: "H2",
            percentual: 4.5
          },
          {
            id: "N2",
            percentual: 54.1
          },
          {
            id: "O2",
            percentual: 0.4
          }
        ]
      },
      bof: {
        nome: "Gás de aciaria / BOF / LD",
        observacao: "Composição representativa em base molar; ajuste pela análise real.",
        componentes: [
          {
            id: "CO",
            percentual: 65.0
          },
          {
            id: "CO2",
            percentual: 18.0
          },
          {
            id: "N2",
            percentual: 16.9
          },
          {
            id: "O2",
            percentual: 0.1
          }
        ]
      },
      gn: {
        nome: "Gás natural",
        observacao:
          "Composição representativa em base molar; ajuste conforme cromatografia/fornecedor.",
        componentes: [
          {
            id: "CH4",
            percentual: 93.9
          },
          {
            id: "C2H6",
            percentual: 3.2
          },
          {
            id: "C3H8",
            percentual: 0.7
          },
          {
            id: "C4H10_NBUTANO",
            percentual: 0.2
          },
          {
            id: "C4H10_ISOBUTANO",
            percentual: 0.2
          },
          {
            id: "N2",
            percentual: 1.0
          },
          {
            id: "CO2",
            percentual: 0.8
          }
        ]
      },
      ar_seco: {
        nome: "Ar atmosférico seco",
        observacao:
          "Ar seco aproximado em base molar/volumétrica: N₂ 78,08%, O₂ 20,95%, Ar 0,93% e CO₂ 0,04%. Sem vapor de água; demais gases-traço omitidos. Fonte de referência: NOAA JetStream. É comburente/diluente, não combustível. Como entrada de combustível isolada, não produz combustão.",
        componentes: [
          { id: "N2", percentual: 78.08 },
          { id: "O2", percentual: 20.95 },
          { id: "AR", percentual: 0.93 },
          { id: "CO2", percentual: 0.04 }
        ]
      },
      glp: {
        nome: "GLP",
        observacao: "Exemplo 60/40 molar de propano/n-butano; ajuste conforme produto real.",
        componentes: [
          {
            id: "C3H8",
            percentual: 60.0
          },
          {
            id: "C4H10_NBUTANO",
            percentual: 40.0
          }
        ]
      }
    };
  }
};
const __cache = new Map();
function __load(id) {
  if (__cache.has(id)) return __cache.get(id);
  const load = __modules[id];
  if (!load) throw new Error("Módulo ausente: " + id);
  const exports = Object.create(null);
  __cache.set(id, exports);
  try {
    load(__load, exports);
  } catch (error) {
    __cache.delete(id);
    throw error;
  }
  return exports;
}
__load("database.js");
__load("presets.js");

/** Revisão termodinâmica 22/10/2026.
 * Mantém os dados recebidos em dadosLegados para rastreabilidade.
 * PCS/PCI revisados por ΔfH° a 298,15 K, combustível gasoso;
 * C→CO2(g), H→H2O(l)/(g), S→SO2(g), N→N2.
 * Demais PCS legados são uma hipótese estimada a 25°C, NÃO certificação ISO.
 */
(function revisarReferenciasTermodinamicas() {
  const byId = (id) => window.GAS_DATABASE.find((g) => g.id === id);
  const hf = { CO2: -393.5224, H2Og: -241.8264, H2Ol: -285.8304, SO2: -296.8422 };
  const revisados = {
    H2: [0, "C1333740", "Chase (1998), estado elementar de referência"],
    CO: [-110.5271, "C630080", "Chase (1998)"],
    CH4: [-74.8731, "C74828", "Chase (1998)"],
    H2S: [-20.50202, "C7783064", "Chase (1998)"],
    C2H2: [226.7314, "C74862", "Chase (1998)"],
    C2H4: [52.46694, "C74851", "Chase (1998)"],
    C2H6: [-84.0, "C74840", "Manion (2002), recomendação adotada de Gurvich et al."],
    C3H8: [-104.7, "C74986", "Pittam e Pilcher (1972)"],
    C4H10_NBUTANO: [-125.6, "C106978", "Pittam e Pilcher (1972)"],
    C4H10_ISOBUTANO: [-134.2, "C75285", "Pittam e Pilcher (1972)"]
  };
  for (const gas of window.GAS_DATABASE) {
    gas.dadosLegados = { pcs: gas.pcs, pci: gas.pci, fontePcsPci: gas.fontePcsPci };
    if (!(gas.pcs > 0)) continue;
    const water = gas.atomos.H / 2;
    const reviewed = revisados[gas.id];
    gas.referenciaEnergia = {
      temperaturaK: 298.15,
      faseCombustivel: "gasosa",
      faseAguaPCS: "líquida",
      faseAguaPCI: "vapor",
      status: reviewed ? "referencia" : "estimativa_referencia_nao_confirmada"
    };
    if (reviewed) {
      const [hfFuel, cas, citation] = reviewed;
      gas.pcs =
        (hfFuel - gas.atomos.C * hf.CO2 - water * hf.H2Ol - gas.atomos.S * hf.SO2) / gas.massaMolar;
      gas.referenciaEnergia.entalpiaFormacaoKJMol = hfFuel;
      gas.referenciaEnergia.url = `https://webbook.nist.gov/cgi/cbook.cgi?ID=${cas}&Mask=1`;
      gas.referenciaEnergia.citacao = citation;
      gas.fontePcsPci = `NIST WebBook / ${citation}; calculado por entalpias de formação a 25 °C`;
    } else {
      gas.fontePcsPci =
        "Estimativa: PCS legado interpretado a 25 °C (referência original não confirmada); PCI recalculado com ΔHvap de 44,004 kJ/mol";
    }
    gas.pci = gas.pcs - (water * (hf.H2Og - hf.H2Ol)) / gas.massaMolar;
  }
  // Cp tabulado: interpolação linear representada exatamente em faixas Shomate A+Bt.
  // Fonte: NIST WebBook, tabela Cp ideal recomendada; não mistura dados de líquido.
  const T = [273.15, 298.15, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300];
  const tabulados = {
    C2H6: {
      cas: "C74840",
      T: [200, 298.15, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300],
      cp: [
        42.3, 52.49, 52.71, 65.46, 77.94, 89.19, 99.14, 107.94, 115.71, 122.55, 128.55, 133.8,
        138.39
      ],
      citacao: "Gurvich et al. (1989)"
    },
    C3H8: {
      cas: "C74986",
      T,
      cp: [
        68.74, 73.6, 73.93, 94.01, 112.59, 128.7, 142.67, 154.77, 165.35, 174.6, 182.67, 189.74,
        195.85
      ],
      citacao: "Chao (1973)"
    },
    C4H10_NBUTANO: {
      cas: "C106978",
      T,
      cp: [
        92.3, 98.49, 98.95, 124.77, 148.66, 169.28, 187.02, 202.38, 215.73, 227.36, 237.48, 246.27,
        253.93
      ],
      citacao: "Chen et al. (1975)"
    },
    C4H10_ISOBUTANO: {
      cas: "C75285",
      T,
      cp: [
        89.91, 96.65, 97.15, 124.43, 149.24, 170.37, 188.28, 203.64, 216.94, 228.45, 238.49, 247.15,
        254.72
      ],
      citacao: "Chen et al. (1975)"
    }
  };
  for (const [id, table] of Object.entries(tabulados)) {
    const gas = byId(id);
    gas.dadosLegados.cpShomate = gas.cpShomate;
    gas.cpShomate = {
      metodo: "NIST_TABELA_LINEAR",
      estimado: false,
      interpolado: true,
      fonte: `NIST WebBook / ${table.citacao}; interpolação linear do Cp ideal tabulado`,
      url: `https://webbook.nist.gov/cgi/cbook.cgi?ID=${table.cas}&Mask=1`,
      pontos: table.T.map((T, i) => ({ T, cp: table.cp[i] })),
      faixas: table.T.slice(0, -1).map((T, i) => {
        const slope = (table.cp[i + 1] - table.cp[i]) / (table.T[i + 1] - T);
        return {
          Tmin: T,
          Tmax: table.T[i + 1],
          A: table.cp[i] - slope * T,
          B: slope * 1000,
          C: 0,
          D: 0,
          E: 0,
          F: null,
          G: null,
          H: null
        };
      })
    };
  }
})();
